package com.example.shiryabdo.onesearchapp.models;

public class GameType {
    public final static String Timed = "T", Infinite = "I";
}

