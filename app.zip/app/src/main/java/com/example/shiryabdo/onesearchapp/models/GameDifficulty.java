package com.example.shiryabdo.onesearchapp.models;

public class GameDifficulty {
    public static final String Easy = "E", Medium = "M", Hard = "H", Advanced = "A";
}
