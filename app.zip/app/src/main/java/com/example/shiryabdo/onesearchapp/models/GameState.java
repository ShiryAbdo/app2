package com.example.shiryabdo.onesearchapp.models;

public class GameState {
    public static final String START = "s", PLAY = "p", PAUSE = "a", FINISHED = "f";
}
