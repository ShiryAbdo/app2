package com.example.shiryabdo.onesearchapp.wordSearchGenerator.models;

public class FillType {
    public static final String RandomCharacters = "RC";
    public static final String CharactersOfTheWord = "CW";
}
